<?php
define ("BR", "<br />\n");
define("MAX_CANT", 5000);
define("VALS", [
    "dolar" => ["literal" => "dólares", "tipo" => 1.16],
    "libra" => ["literal" => "libras", "tipo" => 0.86],
    "yen" => ["literal" => "yenes", "tipo" => 129.852],
    "leu" => ["literal" => "lei", "tipo" => 4.87],
    "liras" => ["literal" => "liras turcas", "tipo" => 10.15],
    "pesetas" => ["literal" => "pesetas", "tipo" => 166.386]
]);

